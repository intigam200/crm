# Supply Chain CRM - Система управления снабжением

Полнофункциональная CRM-платформа для управления процессом снабжения, RFQ (Request for Quotation), поставщиками и email-коммуникацией.

## 🚀 Возможности

### ✅ Управление RFQ
- Автоматическое создание RFQ из входящих email
- Отслеживание статусов: NEW → SEARCHING → QUOTATION → PRICE_SET → NEGOTIATION → LOGISTICS → COMPLETED
- Управление приоритетами (LOW, MEDIUM, HIGH, URGENT)
- История всех запросов с поиском и фильтрацией
- Прикрепление файлов и документов

### ✅ CRM - База компаний
- Управление поставщиками, дистрибьюторами и клиентами
- Контактные лица с полной информацией
- Рейтинг компаний (0-5 звезд)
- История взаимодействий (email, звонки, встречи)
- Поиск и фильтрация по типу, стране, названию

### ✅ Управление котировками
- Получение и сравнение котировок от поставщиков
- Расчет маржи
- Отслеживание сроков действия котировок
- Условия поставки (Incoterms: FOB, CIF, EXW и т.д.)
- Сроки доставки и условия оплаты

### ✅ Email интеграция
- Автоматическое получение писем через IMAP (Gmail/Outlook)
- Автоматическое распознавание RFQ в письмах
- Отправка писем через SMTP
- Шаблоны писем для ускорения коммуникации
- Привязка переписки к RFQ

### ✅ Dashboard и аналитика
- Ключевые метрики в реальном времени
- Статистика по RFQ, компаниям, котировкам
- Последние активности
- Быстрые действия

## 📋 Технологический стек

- **Frontend & Backend:** Next.js 14 (React, TypeScript)
- **База данных:** PostgreSQL
- **ORM:** Prisma
- **Email:** nodemailer (SMTP), imap (IMAP)
- **Стили:** Tailwind CSS
- **Иконки:** Lucide React

## 🛠 Установка

### Предварительные требования

- Node.js 18+ 
- PostgreSQL 14+
- npm или yarn
- Email аккаунт (Gmail/Outlook) для интеграции

### Шаг 1: Клонирование и установка зависимостей

```bash
# Перейдите в директорию проекта
cd supply-chain-crm

# Установите зависимости
npm install
```

### Шаг 2: Настройка базы данных PostgreSQL

```bash
# Создайте базу данных PostgreSQL
createdb supply_crm

# Или через psql:
psql -U postgres
CREATE DATABASE supply_crm;
\q
```

### Шаг 3: Настройка переменных окружения

Скопируйте `.env.example` в `.env`:

```bash
cp .env.example .env
```

Отредактируйте `.env` файл:

```env
# Database
DATABASE_URL="postgresql://username:password@localhost:5432/supply_crm?schema=public"

# Email Configuration (Gmail пример)
EMAIL_HOST="imap.gmail.com"
EMAIL_PORT=993
EMAIL_USER="your-email@gmail.com"
EMAIL_PASSWORD="your-app-password"  # См. инструкцию ниже
EMAIL_SECURE=true

# SMTP для отправки
SMTP_HOST="smtp.gmail.com"
SMTP_PORT=587
SMTP_USER="your-email@gmail.com"
SMTP_PASSWORD="your-app-password"

# Next.js
NEXT_PUBLIC_API_URL="http://localhost:3000"
NEXTAUTH_SECRET="your-random-secret-key"
NEXTAUTH_URL="http://localhost:3000"
```

#### Настройка Gmail App Password

1. Перейдите в настройки Google Account: https://myaccount.google.com/security
2. Включите двухфакторную аутентификацию (если еще не включена)
3. Перейдите в "App passwords": https://myaccount.google.com/apppasswords
4. Создайте новый App Password для "Mail"
5. Используйте сгенерированный пароль в `.env` файле

### Шаг 4: Инициализация базы данных

```bash
# Применить миграции Prisma
npx prisma db push

# Заполнить базу тестовыми данными (опционально)
npm run db:seed

# Открыть Prisma Studio для просмотра данных (опционально)
npm run db:studio
```

### Шаг 5: Запуск приложения

```bash
# Development режим
npm run dev

# Приложение будет доступно на http://localhost:3000
```

## 📂 Структура проекта

```
supply-chain-crm/
├── app/                          # Next.js App Router
│   ├── api/                      # API Routes
│   │   ├── rfq/                  # RFQ endpoints
│   │   ├── companies/            # Компании endpoints
│   │   ├── emails/               # Email endpoints
│   │   └── dashboard/            # Dashboard stats
│   ├── globals.css               # Глобальные стили
│   ├── layout.tsx                # Главный layout
│   └── page.tsx                  # Главная страница (Dashboard)
│
├── lib/                          # Утилиты и сервисы
│   ├── prisma.ts                 # Prisma client
│   └── email-service.ts          # Email сервис (IMAP/SMTP)
│
├── prisma/                       # Prisma schema и миграции
│   ├── schema.prisma             # Схема базы данных
│   └── seed.js                   # Тестовые данные
│
├── .env                          # Переменные окружения (не в git)
├── .env.example                  # Пример переменных
├── package.json                  # Зависимости
├── tsconfig.json                 # TypeScript конфигурация
├── tailwind.config.js            # Tailwind конфигурация
└── README.md                     # Документация
```

## 🔧 API Endpoints

### RFQ

```
GET    /api/rfq              # Получить все RFQ
GET    /api/rfq?status=NEW   # Фильтр по статусу
POST   /api/rfq              # Создать новый RFQ
GET    /api/rfq/[id]         # Получить конкретный RFQ
PATCH  /api/rfq/[id]         # Обновить RFQ
DELETE /api/rfq/[id]         # Удалить RFQ
```

### Companies

```
GET    /api/companies                   # Получить все компании
GET    /api/companies?type=SUPPLIER     # Фильтр по типу
GET    /api/companies?search=tech       # Поиск по названию
POST   /api/companies                   # Создать компанию
GET    /api/companies/[id]              # Получить компанию
PATCH  /api/companies/[id]              # Обновить компанию
DELETE /api/companies/[id]              # Удалить компанию
```

### Emails

```
GET    /api/emails              # Получить все emails
GET    /api/emails?rfqId=xxx    # Emails для конкретного RFQ
POST   /api/emails              # Отправить email
POST   /api/emails/sync         # Синхронизация с почтой
```

### Dashboard

```
GET    /api/dashboard/stats     # Статистика dashboard
```

## 📊 Схема базы данных

### Основные таблицы:

- **Company** - Компании (поставщики, дистрибьюторы, клиенты)
- **Contact** - Контактные лица в компаниях
- **RFQ** - Запросы на котировку
- **RFQItem** - Позиции в RFQ
- **Quote** - Котировки от поставщиков
- **QuoteItem** - Позиции в котировках
- **Email** - Email переписка
- **Interaction** - История взаимодействий
- **User** - Пользователи системы

### Статусы RFQ:

1. **NEW** - Новый запрос (получен email)
2. **SEARCHING** - Поиск поставщиков
3. **QUOTATION** - Получение котировок
4. **PRICE_SET** - Цена установлена дистрибьютором
5. **NEGOTIATION** - Переговоры с клиентом
6. **LOGISTICS** - Организация логистики
7. **COMPLETED** - Завершено
8. **CANCELLED** - Отменено

## 🔄 Автоматическая обработка Email

Система автоматически:

1. **Получает новые письма** через IMAP
2. **Распознает RFQ** по ключевым словам (rfq, quote request, quotation)
3. **Создает RFQ** в системе автоматически
4. **Извлекает номер RFQ** из темы письма
5. **Создает/находит компанию клиента** по email
6. **Привязывает переписку** к RFQ

### Запуск синхронизации вручную:

```bash
# Через API
curl -X POST http://localhost:3000/api/emails/sync
```

### Автоматическая синхронизация (рекомендуется):

Добавьте cron job для регулярной проверки почты:

```bash
# Каждые 5 минут
*/5 * * * * curl -X POST http://localhost:3000/api/emails/sync
```

## 💡 Использование

### Создание RFQ вручную

```javascript
// POST /api/rfq
{
  "title": "Электронные компоненты",
  "description": "Требуются микроконтроллеры",
  "status": "NEW",
  "priority": "HIGH",
  "clientCompanyId": "company-id",
  "deadline": "2026-03-01",
  "estimatedValue": 50000,
  "currency": "USD",
  "items": [
    {
      "partNumber": "STM32F407",
      "description": "Микроконтроллер",
      "quantity": 500,
      "unit": "pcs",
      "targetPrice": 12.5
    }
  ]
}
```

### Отправка email

```javascript
// POST /api/emails
{
  "to": "supplier@example.com",
  "subject": "Quote Request: RFQ-2024-001",
  "text": "Please provide pricing...",
  "rfqId": "rfq-id"
}
```

## 🎯 Типичный workflow

1. **Клиент отправляет RFQ на почту** → Система автоматически создает RFQ
2. **Менеджер проверяет RFQ** → Заполняет детали, устанавливает приоритет
3. **Поиск поставщиков** → Выбор компаний из базы или добавление новых
4. **Отправка запросов котировок** → Массовая рассылка через email
5. **Получение котировок** → Сохранение и сравнение предложений
6. **Установка цены** → Дистрибьютор устанавливает финальную цену
7. **Организация логистики** → Оформление доставки
8. **Завершение сделки** → Статус COMPLETED

## 🔐 Безопасность

- Используйте App Passwords для Gmail (не основной пароль)
- Храните `.env` в безопасности (не коммитьте в git)
- Используйте сложные пароли для БД
- В production используйте HTTPS
- Настройте firewall для PostgreSQL

## 🚀 Deployment (Production)

### Vercel (рекомендуется для Next.js)

```bash
# Установите Vercel CLI
npm i -g vercel

# Deploy
vercel --prod
```

Настройте переменные окружения в Vercel Dashboard.

### Docker (альтернатива)

```dockerfile
# Создайте Dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm install
COPY . .
RUN npx prisma generate
RUN npm run build
CMD ["npm", "start"]
```

```bash
docker build -t supply-crm .
docker run -p 3000:3000 supply-crm
```

## 📝 TODO / Будущие улучшения

- [ ] Аутентификация пользователей (NextAuth.js)
- [ ] Роли и права доступа (Admin, Manager, User)
- [ ] Продвинутая аналитика и отчеты
- [ ] Export данных в Excel/PDF
- [ ] Уведомления (email, push)
- [ ] Календарь и напоминания
- [ ] Интеграция с ERP системами
- [ ] Мобильное приложение
- [ ] Многоязычность
- [ ] Webhook для интеграций

## 🐛 Troubleshooting

### Ошибка подключения к PostgreSQL

```bash
# Проверьте что PostgreSQL запущен
sudo systemctl status postgresql

# Проверьте строку подключения в .env
```

### Ошибка email аутентификации

- Убедитесь что используете App Password, а не основной пароль Gmail
- Проверьте что двухфакторная аутентификация включена
- Для Outlook: включите IMAP в настройках

### Prisma ошибки

```bash
# Пересоздать клиент Prisma
npx prisma generate

# Сбросить базу данных (осторожно!)
npx prisma db push --force-reset
```

## 📞 Поддержка

Для вопросов и предложений создайте issue в репозитории проекта.

## 📄 Лицензия

MIT License - используйте свободно для коммерческих и личных проектов.

---

**Разработано для автоматизации процессов снабжения и управления RFQ** 🚀
