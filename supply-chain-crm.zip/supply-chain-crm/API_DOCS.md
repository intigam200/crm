# API Documentation - Supply Chain CRM

## Base URL
```
http://localhost:3000/api
```

## Authentication
В текущей версии аутентификация не реализована. В production добавьте JWT/Session auth.

---

## 📋 RFQ Endpoints

### GET /api/rfq
Получить список всех RFQ

**Query Parameters:**
- `status` (optional) - Фильтр по статусу (NEW, SEARCHING, QUOTATION, PRICE_SET, NEGOTIATION, LOGISTICS, COMPLETED, CANCELLED)
- `limit` (optional) - Количество записей (default: 50)

**Response:**
```json
[
  {
    "id": "rfq_clx123abc",
    "rfqNumber": "RFQ-2024-001",
    "title": "Электронные компоненты",
    "description": "Требуются микроконтроллеры...",
    "status": "QUOTATION",
    "priority": "HIGH",
    "clientCompany": {
      "id": "company_123",
      "name": "Industrial Solutions Inc"
    },
    "items": [...],
    "quotes": [...],
    "receivedDate": "2026-02-14T00:00:00Z",
    "deadline": "2026-02-28T00:00:00Z",
    "estimatedValue": 45000,
    "currency": "USD"
  }
]
```

### POST /api/rfq
Создать новый RFQ

**Request Body:**
```json
{
  "title": "Название RFQ",
  "description": "Описание",
  "status": "NEW",
  "priority": "HIGH",
  "clientCompanyId": "company_id",
  "receivedDate": "2026-02-14",
  "deadline": "2026-03-01",
  "estimatedValue": 50000,
  "currency": "USD",
  "deliveryAddress": "123 Street, City",
  "deliveryTerms": "FOB Shanghai",
  "notes": "Дополнительные заметки",
  "items": [
    {
      "partNumber": "STM32F407",
      "description": "Микроконтроллер ARM",
      "quantity": 500,
      "unit": "pcs",
      "targetPrice": 12.5
    }
  ]
}
```

**Response:** `201 Created`
```json
{
  "id": "rfq_clx123abc",
  "rfqNumber": "RFQ-1707908400000",
  ...
}
```

### GET /api/rfq/[id]
Получить детали конкретного RFQ

**Response:**
```json
{
  "id": "rfq_clx123abc",
  "rfqNumber": "RFQ-2024-001",
  "title": "Электронные компоненты",
  "clientCompany": {...},
  "items": [
    {
      "id": "item_1",
      "partNumber": "STM32F407",
      "description": "Микроконтроллер ARM",
      "quantity": 500,
      "unit": "pcs",
      "targetPrice": 12.5
    }
  ],
  "quotes": [
    {
      "id": "quote_1",
      "supplier": {...},
      "totalPrice": 42500,
      "status": "RECEIVED",
      "items": [...]
    }
  ],
  "emails": [...]
}
```

### PATCH /api/rfq/[id]
Обновить RFQ

**Request Body:** (все поля опциональны)
```json
{
  "title": "Новое название",
  "status": "QUOTATION",
  "priority": "MEDIUM",
  "deadline": "2026-03-15",
  "notes": "Обновленные заметки"
}
```

**Response:** `200 OK` - обновленный RFQ

### DELETE /api/rfq/[id]
Удалить RFQ

**Response:** `200 OK`
```json
{
  "success": true
}
```

---

## 🏢 Companies Endpoints

### GET /api/companies
Получить список компаний

**Query Parameters:**
- `type` (optional) - Фильтр по типу (SUPPLIER, DISTRIBUTOR, CLIENT, OTHER)
- `search` (optional) - Поиск по названию или email

**Response:**
```json
[
  {
    "id": "company_123",
    "name": "Tech Components Ltd",
    "type": "SUPPLIER",
    "email": "sales@techcomponents.com",
    "phone": "+1-555-0101",
    "address": "123 Tech Street",
    "country": "USA",
    "website": "https://techcomponents.com",
    "rating": 5,
    "contacts": [
      {
        "id": "contact_1",
        "firstName": "John",
        "lastName": "Smith",
        "email": "john.smith@techcomponents.com",
        "position": "Sales Manager"
      }
    ],
    "_count": {
      "rfqs": 15,
      "quotes": 23,
      "interactions": 45
    }
  }
]
```

### POST /api/companies
Создать новую компанию

**Request Body:**
```json
{
  "name": "New Supplier Co",
  "type": "SUPPLIER",
  "email": "info@newsupplier.com",
  "phone": "+1-555-1234",
  "address": "456 Business Ave",
  "country": "USA",
  "website": "https://newsupplier.com",
  "rating": 4,
  "notes": "Reliable supplier",
  "contacts": [
    {
      "firstName": "Jane",
      "lastName": "Doe",
      "email": "jane@newsupplier.com",
      "phone": "+1-555-1235",
      "position": "Account Manager"
    }
  ]
}
```

**Response:** `201 Created` - созданная компания

### GET /api/companies/[id]
Получить детали компании

### PATCH /api/companies/[id]
Обновить компанию

### DELETE /api/companies/[id]
Удалить компанию

---

## 📧 Email Endpoints

### GET /api/emails
Получить список emails

**Query Parameters:**
- `rfqId` (optional) - Фильтр по RFQ
- `direction` (optional) - Фильтр по направлению (INCOMING, OUTGOING)
- `limit` (optional) - Количество записей (default: 50)

**Response:**
```json
[
  {
    "id": "email_1",
    "messageId": "<msg123@example.com>",
    "direction": "INCOMING",
    "from": "client@example.com",
    "to": ["sales@yourcompany.com"],
    "cc": [],
    "subject": "RFQ Request",
    "body": "Email text content...",
    "htmlBody": "<html>...</html>",
    "attachments": [
      {
        "filename": "rfq.pdf",
        "contentType": "application/pdf",
        "size": 123456
      }
    ],
    "rfq": {...},
    "receivedAt": "2026-02-14T09:30:00Z",
    "processed": true
  }
]
```

### POST /api/emails
Отправить email

**Request Body:**
```json
{
  "to": "supplier@example.com",
  "subject": "Quote Request: RFQ-2024-001",
  "text": "Plain text version of email",
  "html": "<html><body>HTML version</body></html>",
  "rfqId": "rfq_clx123abc"
}
```

**Response:** `200 OK`
```json
{
  "success": true,
  "messageId": "<sent-msg-id@domain.com>"
}
```

### POST /api/emails/sync
Синхронизация с почтовым сервером (IMAP)

Получает новые письма и автоматически обрабатывает RFQ.

**Response:** `200 OK`
```json
{
  "success": true,
  "message": "Email synchronization completed"
}
```

**Error Response:** `500 Internal Server Error`
```json
{
  "error": "Failed to sync emails",
  "details": "Connection refused..."
}
```

---

## 📊 Dashboard Endpoints

### GET /api/dashboard/stats
Получить статистику для dashboard

**Response:**
```json
{
  "totalRFQs": 156,
  "activeRFQs": 23,
  "totalCompanies": 87,
  "pendingQuotes": 12,
  "totalValue": 1250000,
  "avgResponseTime": "4.5h",
  "recentRFQs": [
    {
      "id": "rfq_1",
      "rfqNumber": "RFQ-2024-001",
      "title": "Electronic Components",
      "status": "QUOTATION",
      "receivedDate": "2026-02-14T00:00:00Z",
      "clientCompany": {...}
    }
  ],
  "unreadEmails": 5
}
```

---

## 💰 Quotes Endpoints

### POST /api/quotes
Создать новую котировку

**Request Body:**
```json
{
  "rfqId": "rfq_clx123abc",
  "supplierId": "company_123",
  "quoteNumber": "QT-2024-001",
  "status": "RECEIVED",
  "totalPrice": 42500,
  "currency": "USD",
  "margin": 15,
  "validUntil": "2026-03-14",
  "deliveryTime": "3-4 weeks",
  "paymentTerms": "30 days net",
  "incoterms": "FOB Shanghai",
  "items": [
    {
      "partNumber": "STM32F407",
      "description": "Микроконтроллер",
      "quantity": 500,
      "unitPrice": 11.8,
      "totalPrice": 5900,
      "leadTime": "3 weeks"
    }
  ]
}
```

---

## Error Responses

Все endpoints возвращают стандартные HTTP коды:

- `200 OK` - Успешный запрос
- `201 Created` - Ресурс создан
- `400 Bad Request` - Неверные параметры
- `404 Not Found` - Ресурс не найден
- `500 Internal Server Error` - Ошибка сервера

**Error Format:**
```json
{
  "error": "Error message description"
}
```

---

## Rate Limiting

В текущей версии rate limiting не реализован. Для production рекомендуется добавить:
- Rate limiting middleware
- API keys для внешних интеграций
- Request throttling

---

## Webhooks (Планируется)

Будущие возможности:
- Webhook при создании нового RFQ
- Webhook при получении котировки
- Webhook при изменении статуса

---

## Examples

### Полный workflow через API

```javascript
// 1. Создать RFQ
const rfq = await fetch('/api/rfq', {
  method: 'POST',
  body: JSON.stringify({
    title: 'New Project Components',
    status: 'NEW',
    items: [...]
  })
})

// 2. Найти поставщиков
const suppliers = await fetch('/api/companies?type=SUPPLIER')

// 3. Отправить запросы котировок
for (const supplier of suppliers) {
  await fetch('/api/emails', {
    method: 'POST',
    body: JSON.stringify({
      to: supplier.email,
      subject: `Quote Request: ${rfq.rfqNumber}`,
      text: generateQuoteRequest(rfq)
    })
  })
}

// 4. Синхронизировать почту
await fetch('/api/emails/sync', { method: 'POST' })

// 5. Обновить статус
await fetch(`/api/rfq/${rfq.id}`, {
  method: 'PATCH',
  body: JSON.stringify({ status: 'QUOTATION' })
})
```

---

**Version:** 1.0.0  
**Last Updated:** February 14, 2026
