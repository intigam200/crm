# 🎯 ИНСТРУКЦИЯ ПО ЗАГРУЗКЕ В VS CODE

## Шаг 1: Скачайте проект

Скачайте папку `supply-chain-crm` из файлов выше и сохраните её на вашем компьютере.

## Шаг 2: Откройте в VS Code

```bash
# Откройте терминал и перейдите в директорию проекта
cd путь/к/supply-chain-crm

# Откройте VS Code
code .
```

Или просто:
1. Откройте VS Code
2. File → Open Folder
3. Выберите папку `supply-chain-crm`

## Шаг 3: Установите зависимости

В терминале VS Code выполните:

```bash
npm install
```

## Шаг 4: Настройте базу данных

### Установите PostgreSQL (если еще не установлен):

**Windows:**
Скачайте с https://www.postgresql.org/download/windows/

**Mac:**
```bash
brew install postgresql
brew services start postgresql
```

**Linux:**
```bash
sudo apt install postgresql postgresql-contrib
sudo systemctl start postgresql
```

### Создайте базу данных:

```bash
createdb supply_crm
```

## Шаг 5: Настройте .env

```bash
cp .env.example .env
```

Отредактируйте `.env` файл (минимальная конфигурация):

```env
DATABASE_URL="postgresql://postgres:password@localhost:5432/supply_crm"
EMAIL_USER="your-email@gmail.com"
EMAIL_PASSWORD="your-app-password"
SMTP_USER="your-email@gmail.com"
SMTP_PASSWORD="your-app-password"
```

**Важно:** Для Gmail используйте App Password, а не основной пароль!
Инструкция: https://support.google.com/accounts/answer/185833

## Шаг 6: Инициализируйте базу

```bash
npx prisma db push
npm run db:seed
```

## Шаг 7: Запустите приложение

```bash
npm run dev
```

Откройте браузер: http://localhost:3000

## 🎉 Готово!

Вы увидите Dashboard с тестовыми данными.

---

## 📚 Что дальше?

1. **Прочитайте README.md** - полная документация
2. **Изучите API_DOCS.md** - все API endpoints
3. **Посмотрите EXAMPLES.md** - примеры использования
4. **Настройте email интеграцию** - для автоматической обработки RFQ

---

## ❓ Проблемы?

Смотрите раздел "Troubleshooting" в README.md

## 🔥 Основные возможности

✅ CRM для управления компаниями (поставщики, клиенты)
✅ Управление RFQ (запросы на котировку)
✅ Автоматическая обработка email
✅ Отслеживание котировок и цен
✅ Dashboard с аналитикой
✅ История взаимодействий
✅ API для интеграций

---

**Время установки: 5-10 минут** ⏱️
**Требования: Node.js 18+, PostgreSQL 14+** 💻
