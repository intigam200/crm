const { PrismaClient } = require('@prisma/client')

const prisma = new PrismaClient()

async function main() {
  console.log('🌱 Starting database seed...')

  // Создание тестовых компаний-поставщиков
  const supplier1 = await prisma.company.create({
    data: {
      name: 'Tech Components Ltd',
      type: 'SUPPLIER',
      email: 'sales@techcomponents.com',
      phone: '+1-555-0101',
      country: 'USA',
      website: 'https://techcomponents.com',
      rating: 5,
      contacts: {
        create: [
          {
            firstName: 'John',
            lastName: 'Smith',
            email: 'john.smith@techcomponents.com',
            phone: '+1-555-0102',
            position: 'Sales Manager',
          },
        ],
      },
    },
  })

  const supplier2 = await prisma.company.create({
    data: {
      name: 'Global Electronics Supply',
      type: 'SUPPLIER',
      email: 'info@globalelectronics.com',
      phone: '+44-20-5555-0201',
      country: 'UK',
      website: 'https://globalelectronics.com',
      rating: 4,
      contacts: {
        create: [
          {
            firstName: 'Emma',
            lastName: 'Johnson',
            email: 'emma.j@globalelectronics.com',
            phone: '+44-20-5555-0202',
            position: 'Account Manager',
          },
        ],
      },
    },
  })

  const distributor1 = await prisma.company.create({
    data: {
      name: 'Asia Pacific Distributors',
      type: 'DISTRIBUTOR',
      email: 'contact@apdistributors.com',
      phone: '+65-6555-0301',
      country: 'Singapore',
      rating: 4,
      contacts: {
        create: [
          {
            firstName: 'Wei',
            lastName: 'Chen',
            email: 'w.chen@apdistributors.com',
            phone: '+65-6555-0302',
            position: 'Regional Director',
          },
        ],
      },
    },
  })

  const client1 = await prisma.company.create({
    data: {
      name: 'Industrial Solutions Inc',
      type: 'CLIENT',
      email: 'procurement@industrialsolutions.com',
      phone: '+1-555-0401',
      country: 'USA',
      contacts: {
        create: [
          {
            firstName: 'Sarah',
            lastName: 'Williams',
            email: 's.williams@industrialsolutions.com',
            phone: '+1-555-0402',
            position: 'Procurement Manager',
          },
        ],
      },
    },
  })

  console.log('✅ Companies created')

  // Создание тестовых RFQ
  const rfq1 = await prisma.rFQ.create({
    data: {
      rfqNumber: 'RFQ-2024-001',
      title: 'Электронные компоненты для промышленного оборудования',
      description: 'Требуются микроконтроллеры, датчики и силовые модули для производственной линии',
      status: 'QUOTATION',
      priority: 'HIGH',
      clientCompanyId: client1.id,
      receivedDate: new Date('2026-02-14'),
      deadline: new Date('2026-02-28'),
      estimatedValue: 45000,
      currency: 'USD',
      deliveryAddress: '123 Industrial Park, New York, USA',
      deliveryTerms: 'FOB Shanghai',
      items: {
        create: [
          {
            partNumber: 'STM32F407VGT6',
            description: 'Микроконтроллер ARM Cortex-M4',
            quantity: 500,
            unit: 'pcs',
            targetPrice: 12.5,
          },
          {
            partNumber: 'BME280',
            description: 'Датчик температуры и влажности',
            quantity: 1000,
            unit: 'pcs',
            targetPrice: 3.2,
          },
        ],
      },
    },
  })

  const rfq2 = await prisma.rFQ.create({
    data: {
      rfqNumber: 'RFQ-2024-002',
      title: 'Промышленное оборудование и запчасти',
      description: 'Комплектующие для модернизации производственной линии',
      status: 'SEARCHING',
      priority: 'MEDIUM',
      clientCompanyId: client1.id,
      receivedDate: new Date('2026-02-13'),
      deadline: new Date('2026-03-15'),
      estimatedValue: 120000,
      currency: 'USD',
      deliveryTerms: 'CIF New York',
      items: {
        create: [
          {
            partNumber: 'PUMP-1500',
            description: 'Промышленный насос 1500W',
            quantity: 10,
            unit: 'pcs',
          },
          {
            partNumber: 'MOTOR-5HP',
            description: 'Электродвигатель 5HP',
            quantity: 15,
            unit: 'pcs',
          },
        ],
      },
    },
  })

  const rfq3 = await prisma.rFQ.create({
    data: {
      rfqNumber: 'RFQ-2024-003',
      title: 'Расходные материалы для производства',
      description: 'Ежемесячная закупка расходных материалов',
      status: 'LOGISTICS',
      priority: 'LOW',
      receivedDate: new Date('2026-02-13'),
      estimatedValue: 8500,
      currency: 'USD',
      items: {
        create: [
          {
            partNumber: 'SOLDER-WIRE-1KG',
            description: 'Припой в проволоке 1кг',
            quantity: 50,
            unit: 'kg',
            targetPrice: 25,
          },
        ],
      },
    },
  })

  console.log('✅ RFQs created')

  // Создание котировок
  const quote1 = await prisma.quote.create({
    data: {
      rfqId: rfq1.id,
      supplierId: supplier1.id,
      quoteNumber: 'QT-2024-001',
      status: 'RECEIVED',
      totalPrice: 42500,
      currency: 'USD',
      margin: 15,
      validUntil: new Date('2026-03-14'),
      deliveryTime: '3-4 weeks',
      paymentTerms: '30 days net',
      incoterms: 'FOB Shanghai',
      items: {
        create: [
          {
            partNumber: 'STM32F407VGT6',
            description: 'Микроконтроллер ARM Cortex-M4',
            quantity: 500,
            unitPrice: 11.8,
            totalPrice: 5900,
            leadTime: '3 weeks',
          },
          {
            partNumber: 'BME280',
            description: 'Датчик температуры и влажности',
            quantity: 1000,
            unitPrice: 3.0,
            totalPrice: 3000,
            leadTime: '2 weeks',
          },
        ],
      },
    },
  })

  const quote2 = await prisma.quote.create({
    data: {
      rfqId: rfq1.id,
      supplierId: supplier2.id,
      quoteNumber: 'QT-2024-002',
      status: 'PENDING',
      totalPrice: 44000,
      currency: 'USD',
      validUntil: new Date('2026-03-14'),
      deliveryTime: '4-5 weeks',
      paymentTerms: 'LC at sight',
      incoterms: 'CIF New York',
    },
  })

  console.log('✅ Quotes created')

  // Создание тестовых email
  await prisma.email.create({
    data: {
      messageId: '<test-001@example.com>',
      direction: 'INCOMING',
      from: 'procurement@industrialsolutions.com',
      to: ['sales@yourcompany.com'],
      cc: [],
      subject: 'RFQ-2024-001: Request for Electronic Components',
      body: 'Dear Sir/Madam, We would like to request a quotation for electronic components...',
      rfqId: rfq1.id,
      receivedAt: new Date('2026-02-14T09:30:00'),
      processed: true,
    },
  })

  await prisma.email.create({
    data: {
      messageId: '<test-002@example.com>',
      direction: 'OUTGOING',
      from: 'sales@yourcompany.com',
      to: ['sales@techcomponents.com'],
      cc: [],
      subject: 'Quote Request: RFQ-2024-001',
      body: 'Dear John, Could you please provide your best pricing for the attached RFQ?',
      rfqId: rfq1.id,
      sentAt: new Date('2026-02-14T10:15:00'),
      processed: true,
    },
  })

  console.log('✅ Emails created')

  // Создание взаимодействий
  await prisma.interaction.create({
    data: {
      companyId: supplier1.id,
      type: 'EMAIL',
      subject: 'Запрос котировки RFQ-2024-001',
      description: 'Отправлен запрос на котировку электронных компонентов',
      interactedAt: new Date('2026-02-14T10:15:00'),
    },
  })

  await prisma.interaction.create({
    data: {
      companyId: supplier1.id,
      type: 'EMAIL',
      subject: 'Получена котировка QT-2024-001',
      description: 'Получена котировка от Tech Components Ltd',
      interactedAt: new Date('2026-02-14T14:30:00'),
    },
  })

  console.log('✅ Interactions created')

  console.log('🎉 Database seeded successfully!')
}

main()
  .catch((e) => {
    console.error('❌ Error seeding database:', e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
