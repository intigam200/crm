import Imap from 'imap'
import { simpleParser } from 'mailparser'
import nodemailer from 'nodemailer'
import { prisma } from '@/lib/prisma'

interface EmailConfig {
  host: string
  port: number
  user: string
  password: string
  secure: boolean
}

// IMAP конфигурация для получения писем
const imapConfig: EmailConfig = {
  host: process.env.EMAIL_HOST || 'imap.gmail.com',
  port: parseInt(process.env.EMAIL_PORT || '993'),
  user: process.env.EMAIL_USER || '',
  password: process.env.EMAIL_PASSWORD || '',
  secure: process.env.EMAIL_SECURE === 'true',
}

// SMTP конфигурация для отправки писем
const smtpTransporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST || 'smtp.gmail.com',
  port: parseInt(process.env.SMTP_PORT || '587'),
  secure: false,
  auth: {
    user: process.env.SMTP_USER || '',
    pass: process.env.SMTP_PASSWORD || '',
  },
})

/**
 * Подключение к IMAP и получение новых писем
 */
export async function fetchNewEmails(): Promise<void> {
  return new Promise((resolve, reject) => {
    const imap = new Imap({
      user: imapConfig.user,
      password: imapConfig.password,
      host: imapConfig.host,
      port: imapConfig.port,
      tls: imapConfig.secure,
      tlsOptions: { rejectUnauthorized: false },
    })

    imap.once('ready', () => {
      imap.openBox('INBOX', false, (err, box) => {
        if (err) {
          reject(err)
          return
        }

        // Поиск непрочитанных писем
        imap.search(['UNSEEN'], (err, results) => {
          if (err) {
            reject(err)
            return
          }

          if (results.length === 0) {
            console.log('No new emails')
            imap.end()
            resolve()
            return
          }

          const fetch = imap.fetch(results, { bodies: '' })

          fetch.on('message', (msg) => {
            msg.on('body', (stream) => {
              simpleParser(stream, async (err, parsed) => {
                if (err) {
                  console.error('Error parsing email:', err)
                  return
                }

                try {
                  // Сохранение email в базу данных
                  await saveEmailToDatabase(parsed)
                  
                  // Автоматическая обработка RFQ из письма
                  await processRFQFromEmail(parsed)
                } catch (error) {
                  console.error('Error processing email:', error)
                }
              })
            })
          })

          fetch.once('end', () => {
            imap.end()
            resolve()
          })

          fetch.once('error', (err) => {
            reject(err)
          })
        })
      })
    })

    imap.once('error', (err) => {
      reject(err)
    })

    imap.connect()
  })
}

/**
 * Сохранение email в базу данных
 */
async function saveEmailToDatabase(parsed: any) {
  const email = await prisma.email.create({
    data: {
      messageId: parsed.messageId,
      direction: 'INCOMING',
      from: parsed.from?.text || '',
      to: parsed.to?.value?.map((t: any) => t.address) || [],
      cc: parsed.cc?.value?.map((c: any) => c.address) || [],
      subject: parsed.subject || '',
      body: parsed.text || '',
      htmlBody: parsed.html || null,
      attachments: parsed.attachments?.map((a: any) => ({
        filename: a.filename,
        contentType: a.contentType,
        size: a.size,
      })) || null,
      receivedAt: parsed.date || new Date(),
      processed: false,
    },
  })

  console.log('Email saved to database:', email.id)
  return email
}

/**
 * Автоматическая обработка RFQ из письма
 * Ищет ключевые слова: RFQ, quotation, quote request и т.д.
 */
async function processRFQFromEmail(parsed: any) {
  const subject = parsed.subject?.toLowerCase() || ''
  const body = parsed.text?.toLowerCase() || ''

  const rfqKeywords = ['rfq', 'quote request', 'quotation', 'request for quote', 'price request']
  const isRFQ = rfqKeywords.some(keyword => subject.includes(keyword) || body.includes(keyword))

  if (!isRFQ) {
    return
  }

  // Извлечение информации из письма
  const rfqNumber = extractRFQNumber(parsed.subject || '')
  const clientEmail = parsed.from?.value?.[0]?.address

  // Поиск или создание компании-клиента
  let clientCompany = null
  if (clientEmail) {
    clientCompany = await prisma.company.findFirst({
      where: { email: clientEmail },
    })

    if (!clientCompany) {
      const clientName = parsed.from?.value?.[0]?.name || clientEmail
      clientCompany = await prisma.company.create({
        data: {
          name: clientName,
          type: 'CLIENT',
          email: clientEmail,
        },
      })
    }
  }

  // Создание RFQ
  const rfq = await prisma.rFQ.create({
    data: {
      rfqNumber: rfqNumber || `RFQ-${Date.now()}`,
      title: parsed.subject || 'New RFQ from email',
      description: parsed.text?.substring(0, 1000) || '',
      status: 'NEW',
      priority: 'MEDIUM',
      clientCompanyId: clientCompany?.id,
      receivedDate: parsed.date || new Date(),
    },
  })

  // Привязка email к RFQ
  await prisma.email.updateMany({
    where: { messageId: parsed.messageId },
    data: { 
      rfqId: rfq.id,
      processed: true,
    },
  })

  console.log('Created RFQ from email:', rfq.rfqNumber)
}

/**
 * Извлечение номера RFQ из темы письма
 */
function extractRFQNumber(subject: string): string | null {
  const patterns = [
    /RFQ[:\s#-]*(\d+)/i,
    /Quote[:\s#-]*(\d+)/i,
    /REQ[:\s#-]*(\d+)/i,
  ]

  for (const pattern of patterns) {
    const match = subject.match(pattern)
    if (match) {
      return `RFQ-${match[1]}`
    }
  }

  return null
}

/**
 * Отправка email
 */
export async function sendEmail(options: {
  to: string | string[]
  subject: string
  text?: string
  html?: string
  rfqId?: string
}) {
  try {
    const info = await smtpTransporter.sendMail({
      from: process.env.SMTP_USER,
      to: Array.isArray(options.to) ? options.to.join(', ') : options.to,
      subject: options.subject,
      text: options.text,
      html: options.html,
    })

    // Сохранение отправленного email в базу
    await prisma.email.create({
      data: {
        messageId: info.messageId,
        direction: 'OUTGOING',
        from: process.env.SMTP_USER || '',
        to: Array.isArray(options.to) ? options.to : [options.to],
        cc: [],
        subject: options.subject,
        body: options.text || '',
        htmlBody: options.html || null,
        rfqId: options.rfqId,
        sentAt: new Date(),
        processed: true,
      },
    })

    console.log('Email sent:', info.messageId)
    return info
  } catch (error) {
    console.error('Error sending email:', error)
    throw error
  }
}

/**
 * Генерация шаблона письма для запроса котировки
 */
export function generateQuoteRequestTemplate(rfq: any, supplier: any): string {
  return `
Dear ${supplier.name},

We would like to request a quotation for the following items:

RFQ Number: ${rfq.rfqNumber}
Project: ${rfq.title}

${rfq.description || ''}

Please provide your best pricing and availability.

Deadline: ${rfq.deadline ? new Date(rfq.deadline).toLocaleDateString() : 'ASAP'}
Delivery Terms: ${rfq.deliveryTerms || 'To be discussed'}

Looking forward to your response.

Best regards,
${process.env.SMTP_USER}
  `.trim()
}
