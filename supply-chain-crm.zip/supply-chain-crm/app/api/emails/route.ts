import { NextRequest, NextResponse } from 'next/server'
import { fetchNewEmails, sendEmail } from '@/lib/email-service'
import { prisma } from '@/lib/prisma'

// GET /api/emails - Получить все emails
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const rfqId = searchParams.get('rfqId')
    const direction = searchParams.get('direction')
    const limit = parseInt(searchParams.get('limit') || '50')

    let where: any = {}
    
    if (rfqId) {
      where.rfqId = rfqId
    }
    
    if (direction) {
      where.direction = direction
    }

    const emails = await prisma.email.findMany({
      where,
      include: {
        rfq: true,
      },
      orderBy: {
        receivedAt: 'desc',
      },
      take: limit,
    })

    return NextResponse.json(emails)
  } catch (error) {
    console.error('Error fetching emails:', error)
    return NextResponse.json(
      { error: 'Failed to fetch emails' },
      { status: 500 }
    )
  }
}

// POST /api/emails - Отправить email
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    
    const result = await sendEmail({
      to: body.to,
      subject: body.subject,
      text: body.text,
      html: body.html,
      rfqId: body.rfqId,
    })

    return NextResponse.json({ success: true, messageId: result.messageId })
  } catch (error) {
    console.error('Error sending email:', error)
    return NextResponse.json(
      { error: 'Failed to send email' },
      { status: 500 }
    )
  }
}
