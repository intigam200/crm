import { NextRequest, NextResponse } from 'next/server'
import { fetchNewEmails } from '@/lib/email-service'

// POST /api/emails/sync - Синхронизация с почтовым сервером
export async function POST(request: NextRequest) {
  try {
    await fetchNewEmails()
    
    return NextResponse.json({ 
      success: true, 
      message: 'Email synchronization completed' 
    })
  } catch (error) {
    console.error('Error syncing emails:', error)
    return NextResponse.json(
      { error: 'Failed to sync emails', details: error },
      { status: 500 }
    )
  }
}
