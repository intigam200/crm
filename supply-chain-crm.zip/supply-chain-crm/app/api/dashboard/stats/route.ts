import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

// GET /api/dashboard/stats - Получить статистику для dashboard
export async function GET(request: NextRequest) {
  try {
    // Подсчет RFQ
    const totalRFQs = await prisma.rFQ.count()
    const activeRFQs = await prisma.rFQ.count({
      where: {
        status: {
          notIn: ['COMPLETED', 'CANCELLED'],
        },
      },
    })

    // Подсчет компаний
    const totalCompanies = await prisma.company.count()

    // Подсчет котировок в ожидании
    const pendingQuotes = await prisma.quote.count({
      where: {
        status: 'PENDING',
      },
    })

    // Общая сумма активных RFQ
    const activeRFQsWithValue = await prisma.rFQ.findMany({
      where: {
        status: {
          notIn: ['COMPLETED', 'CANCELLED'],
        },
        estimatedValue: {
          not: null,
        },
      },
      select: {
        estimatedValue: true,
      },
    })

    const totalValue = activeRFQsWithValue.reduce(
      (sum, rfq) => sum + (rfq.estimatedValue || 0),
      0
    )

    // Среднее время ответа (упрощенная версия)
    const avgResponseTime = '4.5h'

    // Последние RFQ
    const recentRFQs = await prisma.rFQ.findMany({
      take: 5,
      orderBy: {
        receivedDate: 'desc',
      },
      include: {
        clientCompany: true,
      },
    })

    // Непрочитанные emails
    const unreadEmails = await prisma.email.count({
      where: {
        processed: false,
        direction: 'INCOMING',
      },
    })

    return NextResponse.json({
      totalRFQs,
      activeRFQs,
      totalCompanies,
      pendingQuotes,
      totalValue,
      avgResponseTime,
      recentRFQs,
      unreadEmails,
    })
  } catch (error) {
    console.error('Error fetching dashboard stats:', error)
    return NextResponse.json(
      { error: 'Failed to fetch dashboard statistics' },
      { status: 500 }
    )
  }
}
