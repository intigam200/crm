import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

// GET /api/rfq - Получить все RFQ
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const status = searchParams.get('status')
    const limit = parseInt(searchParams.get('limit') || '50')

    const where = status ? { status } : {}

    const rfqs = await prisma.rFQ.findMany({
      where,
      include: {
        clientCompany: true,
        items: true,
        quotes: {
          include: {
            supplier: true,
          },
        },
      },
      orderBy: {
        receivedDate: 'desc',
      },
      take: limit,
    })

    return NextResponse.json(rfqs)
  } catch (error) {
    console.error('Error fetching RFQs:', error)
    return NextResponse.json(
      { error: 'Failed to fetch RFQs' },
      { status: 500 }
    )
  }
}

// POST /api/rfq - Создать новый RFQ
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    
    const rfq = await prisma.rFQ.create({
      data: {
        rfqNumber: body.rfqNumber || `RFQ-${Date.now()}`,
        title: body.title,
        description: body.description,
        status: body.status || 'NEW',
        priority: body.priority || 'MEDIUM',
        clientCompanyId: body.clientCompanyId,
        receivedDate: body.receivedDate ? new Date(body.receivedDate) : new Date(),
        deadline: body.deadline ? new Date(body.deadline) : null,
        estimatedValue: body.estimatedValue,
        currency: body.currency || 'USD',
        deliveryAddress: body.deliveryAddress,
        deliveryTerms: body.deliveryTerms,
        notes: body.notes,
        items: {
          create: body.items || [],
        },
      },
      include: {
        items: true,
        clientCompany: true,
      },
    })

    return NextResponse.json(rfq, { status: 201 })
  } catch (error) {
    console.error('Error creating RFQ:', error)
    return NextResponse.json(
      { error: 'Failed to create RFQ' },
      { status: 500 }
    )
  }
}
