import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

// GET /api/rfq/[id] - Получить конкретный RFQ
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const rfq = await prisma.rFQ.findUnique({
      where: { id: params.id },
      include: {
        clientCompany: true,
        items: true,
        quotes: {
          include: {
            supplier: true,
            items: true,
          },
        },
        emails: true,
      },
    })

    if (!rfq) {
      return NextResponse.json(
        { error: 'RFQ not found' },
        { status: 404 }
      )
    }

    return NextResponse.json(rfq)
  } catch (error) {
    console.error('Error fetching RFQ:', error)
    return NextResponse.json(
      { error: 'Failed to fetch RFQ' },
      { status: 500 }
    )
  }
}

// PATCH /api/rfq/[id] - Обновить RFQ
export async function PATCH(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json()
    
    const rfq = await prisma.rFQ.update({
      where: { id: params.id },
      data: {
        title: body.title,
        description: body.description,
        status: body.status,
        priority: body.priority,
        deadline: body.deadline ? new Date(body.deadline) : null,
        estimatedValue: body.estimatedValue,
        currency: body.currency,
        deliveryAddress: body.deliveryAddress,
        deliveryTerms: body.deliveryTerms,
        notes: body.notes,
      },
      include: {
        items: true,
        clientCompany: true,
      },
    })

    return NextResponse.json(rfq)
  } catch (error) {
    console.error('Error updating RFQ:', error)
    return NextResponse.json(
      { error: 'Failed to update RFQ' },
      { status: 500 }
    )
  }
}

// DELETE /api/rfq/[id] - Удалить RFQ
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await prisma.rFQ.delete({
      where: { id: params.id },
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error deleting RFQ:', error)
    return NextResponse.json(
      { error: 'Failed to delete RFQ' },
      { status: 500 }
    )
  }
}
