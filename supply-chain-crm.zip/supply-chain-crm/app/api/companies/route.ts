import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

// GET /api/companies - Получить все компании
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const type = searchParams.get('type')
    const search = searchParams.get('search')

    let where: any = {}
    
    if (type) {
      where.type = type
    }
    
    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { email: { contains: search, mode: 'insensitive' } },
      ]
    }

    const companies = await prisma.company.findMany({
      where,
      include: {
        contacts: true,
        _count: {
          select: {
            rfqs: true,
            quotes: true,
            interactions: true,
          },
        },
      },
      orderBy: {
        name: 'asc',
      },
    })

    return NextResponse.json(companies)
  } catch (error) {
    console.error('Error fetching companies:', error)
    return NextResponse.json(
      { error: 'Failed to fetch companies' },
      { status: 500 }
    )
  }
}

// POST /api/companies - Создать новую компанию
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    
    const company = await prisma.company.create({
      data: {
        name: body.name,
        type: body.type || 'SUPPLIER',
        email: body.email,
        phone: body.phone,
        address: body.address,
        country: body.country,
        website: body.website,
        notes: body.notes,
        rating: body.rating || 0,
        contacts: {
          create: body.contacts || [],
        },
      },
      include: {
        contacts: true,
      },
    })

    return NextResponse.json(company, { status: 201 })
  } catch (error) {
    console.error('Error creating company:', error)
    return NextResponse.json(
      { error: 'Failed to create company' },
      { status: 500 }
    )
  }
}
