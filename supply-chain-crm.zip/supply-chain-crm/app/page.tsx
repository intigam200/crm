'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { 
  LayoutDashboard, 
  FileText, 
  Building2, 
  Mail, 
  TrendingUp,
  Package,
  Users,
  DollarSign,
  Clock
} from 'lucide-react'

interface DashboardStats {
  totalRFQs: number
  activeRFQs: number
  totalCompanies: number
  pendingQuotes: number
  totalValue: number
  avgResponseTime: string
}

export default function HomePage() {
  const [stats, setStats] = useState<DashboardStats>({
    totalRFQs: 0,
    activeRFQs: 0,
    totalCompanies: 0,
    pendingQuotes: 0,
    totalValue: 0,
    avgResponseTime: '0h'
  })

  useEffect(() => {
    // Здесь будет загрузка реальных данных из API
    setStats({
      totalRFQs: 156,
      activeRFQs: 23,
      totalCompanies: 87,
      pendingQuotes: 12,
      totalValue: 1250000,
      avgResponseTime: '4.5h'
    })
  }, [])

  const navigation = [
    { name: 'Dashboard', href: '/', icon: LayoutDashboard, current: true },
    { name: 'RFQ', href: '/rfq', icon: FileText, current: false },
    { name: 'Компании', href: '/companies', icon: Building2, current: false },
    { name: 'Email', href: '/emails', icon: Mail, current: false },
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Sidebar */}
      <div className="fixed inset-y-0 left-0 w-64 bg-white border-r border-gray-200">
        <div className="flex flex-col h-full">
          {/* Logo */}
          <div className="flex items-center justify-center h-16 border-b border-gray-200">
            <Package className="w-8 h-8 text-blue-600" />
            <span className="ml-2 text-xl font-bold text-gray-900">Supply CRM</span>
          </div>

          {/* Navigation */}
          <nav className="flex-1 px-4 py-6 space-y-1">
            {navigation.map((item) => (
              <Link
                key={item.name}
                href={item.href}
                className={`flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-colors ${
                  item.current
                    ? 'bg-blue-50 text-blue-700'
                    : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                <item.icon className="w-5 h-5 mr-3" />
                {item.name}
              </Link>
            ))}
          </nav>

          {/* User Info */}
          <div className="p-4 border-t border-gray-200">
            <div className="flex items-center">
              <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center text-white font-medium">
                А
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-900">Администратор</p>
                <p className="text-xs text-gray-500">admin@company.com</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="ml-64">
        {/* Header */}
        <header className="bg-white border-b border-gray-200">
          <div className="px-8 py-4">
            <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
            <p className="text-sm text-gray-500 mt-1">
              Обзор ключевых показателей и активных сделок
            </p>
          </div>
        </header>

        {/* Dashboard Content */}
        <main className="p-8">
          {/* Stats Grid */}
          <div className="grid grid-cols-1 gap-6 mb-8 lg:grid-cols-4">
            {/* Total RFQs */}
            <div className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Всего RFQ</p>
                  <p className="text-3xl font-bold text-gray-900 mt-2">{stats.totalRFQs}</p>
                </div>
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <FileText className="w-6 h-6 text-blue-600" />
                </div>
              </div>
              <div className="mt-4 flex items-center text-sm">
                <TrendingUp className="w-4 h-4 text-green-600 mr-1" />
                <span className="text-green-600 font-medium">+12%</span>
                <span className="text-gray-600 ml-2">за месяц</span>
              </div>
            </div>

            {/* Active RFQs */}
            <div className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Активные</p>
                  <p className="text-3xl font-bold text-gray-900 mt-2">{stats.activeRFQs}</p>
                </div>
                <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                  <Clock className="w-6 h-6 text-orange-600" />
                </div>
              </div>
              <div className="mt-4">
                <span className="text-sm text-gray-600">В работе сейчас</span>
              </div>
            </div>

            {/* Companies */}
            <div className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Компании</p>
                  <p className="text-3xl font-bold text-gray-900 mt-2">{stats.totalCompanies}</p>
                </div>
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                  <Building2 className="w-6 h-6 text-purple-600" />
                </div>
              </div>
              <div className="mt-4">
                <span className="text-sm text-gray-600">В базе данных</span>
              </div>
            </div>

            {/* Total Value */}
            <div className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Общая сумма</p>
                  <p className="text-3xl font-bold text-gray-900 mt-2">
                    ${(stats.totalValue / 1000000).toFixed(1)}M
                  </p>
                </div>
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                  <DollarSign className="w-6 h-6 text-green-600" />
                </div>
              </div>
              <div className="mt-4">
                <span className="text-sm text-gray-600">Активные сделки</span>
              </div>
            </div>
          </div>

          {/* Recent RFQs and Quick Actions */}
          <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
            {/* Recent RFQs */}
            <div className="bg-white rounded-lg shadow">
              <div className="px-6 py-4 border-b border-gray-200">
                <h2 className="text-lg font-semibold text-gray-900">Последние RFQ</h2>
              </div>
              <div className="p-6">
                <div className="space-y-4">
                  {[
                    { id: 'RFQ-2024-001', title: 'Электронные компоненты', status: 'QUOTATION', date: '14.02.2026' },
                    { id: 'RFQ-2024-002', title: 'Промышленное оборудование', status: 'SEARCHING', date: '13.02.2026' },
                    { id: 'RFQ-2024-003', title: 'Расходные материалы', status: 'LOGISTICS', date: '13.02.2026' },
                    { id: 'RFQ-2024-004', title: 'Запчасти для техники', status: 'NEW', date: '12.02.2026' },
                  ].map((rfq) => (
                    <div key={rfq.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                      <div>
                        <p className="font-medium text-gray-900">{rfq.id}</p>
                        <p className="text-sm text-gray-600 mt-1">{rfq.title}</p>
                      </div>
                      <div className="text-right">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                          rfq.status === 'NEW' ? 'bg-blue-100 text-blue-800' :
                          rfq.status === 'SEARCHING' ? 'bg-yellow-100 text-yellow-800' :
                          rfq.status === 'QUOTATION' ? 'bg-purple-100 text-purple-800' :
                          'bg-green-100 text-green-800'
                        }`}>
                          {rfq.status}
                        </span>
                        <p className="text-xs text-gray-500 mt-1">{rfq.date}</p>
                      </div>
                    </div>
                  ))}
                </div>
                <Link 
                  href="/rfq" 
                  className="block text-center mt-4 text-sm font-medium text-blue-600 hover:text-blue-700"
                >
                  Посмотреть все RFQ →
                </Link>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="bg-white rounded-lg shadow">
              <div className="px-6 py-4 border-b border-gray-200">
                <h2 className="text-lg font-semibold text-gray-900">Быстрые действия</h2>
              </div>
              <div className="p-6">
                <div className="space-y-3">
                  <Link
                    href="/rfq/new"
                    className="flex items-center justify-between p-4 border-2 border-dashed border-gray-300 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-colors group"
                  >
                    <div className="flex items-center">
                      <FileText className="w-5 h-5 text-gray-400 group-hover:text-blue-600" />
                      <span className="ml-3 font-medium text-gray-700 group-hover:text-blue-700">
                        Создать новый RFQ
                      </span>
                    </div>
                  </Link>

                  <Link
                    href="/companies/new"
                    className="flex items-center justify-between p-4 border-2 border-dashed border-gray-300 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-colors group"
                  >
                    <div className="flex items-center">
                      <Building2 className="w-5 h-5 text-gray-400 group-hover:text-blue-600" />
                      <span className="ml-3 font-medium text-gray-700 group-hover:text-blue-700">
                        Добавить компанию
                      </span>
                    </div>
                  </Link>

                  <Link
                    href="/emails"
                    className="flex items-center justify-between p-4 border-2 border-dashed border-gray-300 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-colors group"
                  >
                    <div className="flex items-center">
                      <Mail className="w-5 h-5 text-gray-400 group-hover:text-blue-600" />
                      <span className="ml-3 font-medium text-gray-700 group-hover:text-blue-700">
                        Проверить почту
                      </span>
                    </div>
                    {stats.pendingQuotes > 0 && (
                      <span className="px-2.5 py-0.5 bg-red-100 text-red-800 text-xs font-medium rounded-full">
                        {stats.pendingQuotes}
                      </span>
                    )}
                  </Link>
                </div>

                {/* System Status */}
                <div className="mt-6 p-4 bg-green-50 border border-green-200 rounded-lg">
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-green-600 rounded-full animate-pulse"></div>
                    <p className="ml-3 text-sm font-medium text-green-800">
                      Email синхронизация активна
                    </p>
                  </div>
                  <p className="text-xs text-green-600 mt-1 ml-5">
                    Последняя проверка: 2 минуты назад
                  </p>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}
