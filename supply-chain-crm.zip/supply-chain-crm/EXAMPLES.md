# Примеры использования - Supply Chain CRM

## 📝 Содержание

1. [Базовые операции](#базовые-операции)
2. [Email интеграция](#email-интеграция)
3. [Автоматизация workflow](#автоматизация-workflow)
4. [Скрипты для импорта данных](#скрипты-для-импорта-данных)
5. [Интеграция с внешними системами](#интеграция-с-внешними-системами)

---

## Базовые операции

### Создание RFQ из формы

```typescript
// app/components/CreateRFQForm.tsx
'use client'

import { useState } from 'react'

export default function CreateRFQForm() {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    priority: 'MEDIUM',
    deadline: '',
    estimatedValue: 0,
    items: []
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    const response = await fetch('/api/rfq', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData)
    })
    
    if (response.ok) {
      const rfq = await response.json()
      alert(`RFQ создан: ${rfq.rfqNumber}`)
    }
  }

  return (
    <form onSubmit={handleSubmit}>
      {/* Форма */}
    </form>
  )
}
```

### Поиск и фильтрация компаний

```typescript
// Поиск поставщиков электроники
const searchSuppliers = async (keyword: string) => {
  const response = await fetch(
    `/api/companies?type=SUPPLIER&search=${encodeURIComponent(keyword)}`
  )
  return await response.json()
}

// Использование
const electronics = await searchSuppliers('electronics')
console.log(electronics)
```

### Обновление статуса RFQ

```typescript
const updateRFQStatus = async (rfqId: string, newStatus: string) => {
  const response = await fetch(`/api/rfq/${rfqId}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ status: newStatus })
  })
  
  return await response.json()
}

// Переход к следующему этапу
await updateRFQStatus('rfq_123', 'QUOTATION')
```

---

## Email интеграция

### Автоматическая синхронизация каждые 5 минут

```javascript
// scripts/email-sync-cron.js
const cron = require('node-cron')
const axios = require('axios')

// Каждые 5 минут
cron.schedule('*/5 * * * *', async () => {
  try {
    console.log('Starting email sync...')
    const response = await axios.post('http://localhost:3000/api/emails/sync')
    console.log('Sync completed:', response.data)
  } catch (error) {
    console.error('Sync failed:', error.message)
  }
})

console.log('Email sync cron job started')
```

Запуск:
```bash
node scripts/email-sync-cron.js
```

### Отправка шаблонного письма всем поставщикам

```typescript
// lib/email-templates.ts
export const generateQuoteRequestEmail = (rfq: any, supplier: any) => {
  return {
    to: supplier.email,
    subject: `Quote Request: ${rfq.rfqNumber} - ${rfq.title}`,
    html: `
      <!DOCTYPE html>
      <html>
      <head>
        <style>
          body { font-family: Arial, sans-serif; }
          .header { background: #3b82f6; color: white; padding: 20px; }
          .content { padding: 20px; }
          .items { border-collapse: collapse; width: 100%; }
          .items th, .items td { border: 1px solid #ddd; padding: 8px; }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>Quote Request</h1>
        </div>
        <div class="content">
          <p>Dear ${supplier.name},</p>
          <p>We would like to request a quotation for the following:</p>
          
          <h3>RFQ Details</h3>
          <ul>
            <li><strong>RFQ Number:</strong> ${rfq.rfqNumber}</li>
            <li><strong>Project:</strong> ${rfq.title}</li>
            <li><strong>Deadline:</strong> ${new Date(rfq.deadline).toLocaleDateString()}</li>
          </ul>

          <h3>Items Required</h3>
          <table class="items">
            <thead>
              <tr>
                <th>Part Number</th>
                <th>Description</th>
                <th>Quantity</th>
                <th>Unit</th>
              </tr>
            </thead>
            <tbody>
              ${rfq.items.map(item => `
                <tr>
                  <td>${item.partNumber}</td>
                  <td>${item.description}</td>
                  <td>${item.quantity}</td>
                  <td>${item.unit}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>

          <p><strong>Delivery Terms:</strong> ${rfq.deliveryTerms || 'To be discussed'}</p>
          <p><strong>Delivery Address:</strong> ${rfq.deliveryAddress || 'TBD'}</p>

          <p>Please provide your best pricing and lead times.</p>
          
          <p>Best regards,<br>Supply Chain Team</p>
        </div>
      </body>
      </html>
    `
  }
}

// Использование
const sendQuoteRequests = async (rfqId: string) => {
  const rfq = await fetch(`/api/rfq/${rfqId}`).then(r => r.json())
  const suppliers = await fetch('/api/companies?type=SUPPLIER').then(r => r.json())

  for (const supplier of suppliers.slice(0, 5)) { // Топ 5 поставщиков
    const email = generateQuoteRequestEmail(rfq, supplier)
    
    await fetch('/api/emails', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(email)
    })
    
    console.log(`Email sent to ${supplier.name}`)
    await new Promise(resolve => setTimeout(resolve, 1000)) // Rate limiting
  }
}
```

---

## Автоматизация workflow

### Автоматический переход статусов

```typescript
// lib/workflow-automation.ts
export class RFQWorkflowAutomation {
  // Автоматический переход NEW → SEARCHING после создания
  static async onRFQCreated(rfqId: string) {
    // Ждем 5 минут
    await new Promise(resolve => setTimeout(resolve, 5 * 60 * 1000))
    
    await fetch(`/api/rfq/${rfqId}`, {
      method: 'PATCH',
      body: JSON.stringify({ status: 'SEARCHING' })
    })
    
    // Автоматически найти подходящих поставщиков
    await this.findSuitableSuppliers(rfqId)
  }

  // Найти поставщиков на основе истории
  static async findSuitableSuppliers(rfqId: string) {
    const rfq = await fetch(`/api/rfq/${rfqId}`).then(r => r.json())
    
    // Найти поставщиков с высоким рейтингом
    const suppliers = await fetch(
      '/api/companies?type=SUPPLIER'
    ).then(r => r.json())
    
    const topSuppliers = suppliers
      .filter(s => s.rating >= 4)
      .slice(0, 10)
    
    return topSuppliers
  }

  // Напоминание о дедлайне
  static async setupDeadlineReminder(rfqId: string, deadline: Date) {
    const threeDaysBefore = new Date(deadline)
    threeDaysBefore.setDate(threeDaysBefore.getDate() - 3)
    
    const now = new Date()
    const timeUntilReminder = threeDaysBefore.getTime() - now.getTime()
    
    if (timeUntilReminder > 0) {
      setTimeout(async () => {
        // Отправить напоминание
        console.log(`Reminder: RFQ ${rfqId} deadline in 3 days!`)
        // Можно отправить email уведомление
      }, timeUntilReminder)
    }
  }
}
```

### Автоматический расчет маржи

```typescript
// lib/pricing-calculator.ts
export class PricingCalculator {
  // Рассчитать рекомендуемую цену для клиента
  static calculateRecommendedPrice(
    supplierPrice: number,
    targetMargin: number = 15 // 15% маржа
  ) {
    return supplierPrice * (1 + targetMargin / 100)
  }

  // Сравнить котировки
  static compareQuotes(quotes: any[]) {
    return quotes
      .map(quote => ({
        ...quote,
        pricePerUnit: quote.totalPrice / quote.items.reduce((sum, item) => sum + item.quantity, 0),
        score: this.calculateSupplierScore(quote)
      }))
      .sort((a, b) => b.score - a.score)
  }

  // Оценка поставщика (цена + рейтинг + сроки)
  private static calculateSupplierScore(quote: any) {
    const priceScore = 100 - (quote.totalPrice / 1000) // Чем меньше цена, тем лучше
    const ratingScore = quote.supplier.rating * 20 // Рейтинг от 0 до 5
    const deliveryScore = this.parseDeliveryTime(quote.deliveryTime)
    
    return priceScore * 0.5 + ratingScore * 0.3 + deliveryScore * 0.2
  }

  private static parseDeliveryTime(deliveryTime: string): number {
    // Простой парсинг "3-4 weeks" → score
    const match = deliveryTime.match(/(\d+)/)
    const weeks = match ? parseInt(match[1]) : 10
    return Math.max(0, 100 - weeks * 10)
  }
}
```

---

## Скрипты для импорта данных

### Импорт компаний из CSV

```typescript
// scripts/import-companies.ts
import { parse } from 'csv-parse/sync'
import fs from 'fs'

async function importCompaniesFromCSV(filepath: string) {
  const csvContent = fs.readFileSync(filepath, 'utf-8')
  const records = parse(csvContent, {
    columns: true,
    skip_empty_lines: true
  })

  for (const record of records) {
    const company = {
      name: record.name,
      type: record.type || 'SUPPLIER',
      email: record.email,
      phone: record.phone,
      country: record.country,
      website: record.website,
      rating: parseInt(record.rating) || 0
    }

    try {
      const response = await fetch('http://localhost:3000/api/companies', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(company)
      })

      if (response.ok) {
        console.log(`✅ Imported: ${company.name}`)
      } else {
        console.error(`❌ Failed: ${company.name}`)
      }
    } catch (error) {
      console.error(`Error importing ${company.name}:`, error)
    }

    // Rate limiting
    await new Promise(resolve => setTimeout(resolve, 100))
  }

  console.log('Import completed!')
}

// Использование:
// node scripts/import-companies.ts companies.csv
importCompaniesFromCSV(process.argv[2])
```

**Формат CSV:**
```csv
name,type,email,phone,country,website,rating
Tech Components Ltd,SUPPLIER,sales@techcomponents.com,+1-555-0101,USA,https://techcomponents.com,5
Global Electronics,SUPPLIER,info@globalelectronics.com,+44-20-5555-0201,UK,https://globalelectronics.com,4
```

### Экспорт RFQ в Excel

```typescript
// scripts/export-rfqs.ts
import * as XLSX from 'xlsx'

async function exportRFQsToExcel() {
  const response = await fetch('http://localhost:3000/api/rfq')
  const rfqs = await response.json()

  const data = rfqs.map(rfq => ({
    'RFQ Number': rfq.rfqNumber,
    'Title': rfq.title,
    'Status': rfq.status,
    'Priority': rfq.priority,
    'Client': rfq.clientCompany?.name || 'N/A',
    'Value': rfq.estimatedValue,
    'Currency': rfq.currency,
    'Received': new Date(rfq.receivedDate).toLocaleDateString(),
    'Deadline': rfq.deadline ? new Date(rfq.deadline).toLocaleDateString() : 'N/A'
  }))

  const worksheet = XLSX.utils.json_to_sheet(data)
  const workbook = XLSX.utils.book_new()
  XLSX.utils.book_append_sheet(workbook, worksheet, 'RFQs')

  XLSX.writeFile(workbook, `rfqs-export-${Date.now()}.xlsx`)
  console.log('Export completed!')
}

exportRFQsToExcel()
```

---

## Интеграция с внешними системами

### Webhook для уведомлений в Slack

```typescript
// lib/slack-notifications.ts
export class SlackNotifier {
  private webhookUrl: string

  constructor(webhookUrl: string) {
    this.webhookUrl = webhookUrl
  }

  async notifyNewRFQ(rfq: any) {
    await fetch(this.webhookUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        text: `🆕 New RFQ Received`,
        blocks: [
          {
            type: 'section',
            text: {
              type: 'mrkdwn',
              text: `*${rfq.rfqNumber}: ${rfq.title}*\nPriority: ${rfq.priority}\nValue: $${rfq.estimatedValue}`
            }
          },
          {
            type: 'actions',
            elements: [
              {
                type: 'button',
                text: { type: 'plain_text', text: 'View RFQ' },
                url: `http://localhost:3000/rfq/${rfq.id}`
              }
            ]
          }
        ]
      })
    })
  }

  async notifyQuoteReceived(rfq: any, quote: any) {
    await fetch(this.webhookUrl, {
      method: 'POST',
      body: JSON.stringify({
        text: `💰 New Quote for ${rfq.rfqNumber} from ${quote.supplier.name}: $${quote.totalPrice}`
      })
    })
  }
}

// Использование в API route
// app/api/rfq/route.ts
const slack = new SlackNotifier(process.env.SLACK_WEBHOOK_URL!)

export async function POST(request: NextRequest) {
  const rfq = await createRFQ(...)
  await slack.notifyNewRFQ(rfq)
  return NextResponse.json(rfq)
}
```

### REST API клиент для внешних систем

```typescript
// lib/api-client.ts
export class SupplyCRMClient {
  private baseUrl: string
  private apiKey?: string

  constructor(baseUrl: string, apiKey?: string) {
    this.baseUrl = baseUrl
    this.apiKey = apiKey
  }

  private async request(endpoint: string, options?: RequestInit) {
    const headers: HeadersInit = {
      'Content-Type': 'application/json',
      ...(this.apiKey && { 'Authorization': `Bearer ${this.apiKey}` }),
      ...options?.headers
    }

    const response = await fetch(`${this.baseUrl}${endpoint}`, {
      ...options,
      headers
    })

    if (!response.ok) {
      throw new Error(`API Error: ${response.statusText}`)
    }

    return response.json()
  }

  // RFQ methods
  async getRFQs(filters?: { status?: string; limit?: number }) {
    const params = new URLSearchParams(filters as any)
    return this.request(`/api/rfq?${params}`)
  }

  async createRFQ(data: any) {
    return this.request('/api/rfq', {
      method: 'POST',
      body: JSON.stringify(data)
    })
  }

  async updateRFQ(id: string, data: any) {
    return this.request(`/api/rfq/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(data)
    })
  }

  // Companies methods
  async getCompanies(filters?: { type?: string; search?: string }) {
    const params = new URLSearchParams(filters as any)
    return this.request(`/api/companies?${params}`)
  }

  // Email methods
  async sendEmail(data: any) {
    return this.request('/api/emails', {
      method: 'POST',
      body: JSON.stringify(data)
    })
  }

  async syncEmails() {
    return this.request('/api/emails/sync', { method: 'POST' })
  }
}

// Использование
const client = new SupplyCRMClient('http://localhost:3000')
const rfqs = await client.getRFQs({ status: 'QUOTATION' })
```

---

## Production Tips

### Логирование и мониторинг

```typescript
// lib/logger.ts
import pino from 'pino'

export const logger = pino({
  level: process.env.LOG_LEVEL || 'info',
  transport: {
    target: 'pino-pretty',
    options: {
      colorize: true
    }
  }
})

// Использование
logger.info({ rfqId: 'rfq_123' }, 'RFQ created')
logger.error({ error: err }, 'Email sync failed')
```

### Кэширование с Redis

```typescript
// lib/cache.ts
import Redis from 'ioredis'

const redis = new Redis(process.env.REDIS_URL)

export async function cacheRFQs() {
  const rfqs = await prisma.rFQ.findMany()
  await redis.set('rfqs:all', JSON.stringify(rfqs), 'EX', 300) // 5 минут
}

export async function getCachedRFQs() {
  const cached = await redis.get('rfqs:all')
  return cached ? JSON.parse(cached) : null
}
```

---

**Больше примеров смотрите в документации API и README.md**
