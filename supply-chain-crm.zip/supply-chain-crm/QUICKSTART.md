# 🚀 Быстрый старт - Supply Chain CRM

## Установка за 5 минут

### 1. Установите зависимости
```bash
npm install
```

### 2. Настройте базу данных

Создайте PostgreSQL базу данных:
```bash
createdb supply_crm
```

### 3. Настройте .env файл

Скопируйте `.env.example` в `.env` и заполните:
```bash
cp .env.example .env
```

**Минимальная конфигурация:**
```env
DATABASE_URL="postgresql://username:password@localhost:5432/supply_crm?schema=public"
EMAIL_USER="your-email@gmail.com"
EMAIL_PASSWORD="your-app-password"
SMTP_USER="your-email@gmail.com"
SMTP_PASSWORD="your-app-password"
```

### 4. Инициализируйте БД

```bash
# Создать таблицы
npx prisma db push

# Заполнить тестовыми данными
npm run db:seed
```

### 5. Запустите приложение

```bash
npm run dev
```

Откройте http://localhost:3000 🎉

## Что дальше?

1. **Проверьте Dashboard** - увидите тестовые данные
2. **Настройте email интеграцию** - следуйте инструкции в README.md
3. **Создайте первый RFQ** - используйте форму или отправьте email
4. **Добавьте компании** - заполните базу поставщиков

## Помощь

- **Полная документация:** См. README.md
- **Проблемы с установкой:** Проверьте секцию Troubleshooting
- **API документация:** См. раздел API Endpoints в README

## Основные команды

```bash
npm run dev          # Запуск development сервера
npm run build        # Сборка для production
npm run start        # Запуск production сервера
npm run db:studio    # Открыть Prisma Studio
npm run db:seed      # Заполнить БД тестовыми данными
```

---

**Время установки: ~5 минут** ⚡
**Сложность: Легко** 🟢
